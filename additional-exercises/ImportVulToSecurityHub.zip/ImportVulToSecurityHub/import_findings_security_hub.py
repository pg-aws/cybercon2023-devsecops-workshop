"""
 Imports finding in Security Hub and upload the reports to S3 
 Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 SPDX-License-Identifier: MIT-0
"""

import os
import json
import logging
import boto3
import securityhub
from pprint import pprint
from datetime import datetime, timezone

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

FINDING_TITLE = "CodeAnalysis"
FINDING_DESCRIPTION_TEMPLATE = "Summarized report of code scan with {0}"
FINDING_TYPE_TEMPLATE = "{0} code scan"
finding_note = ""
REMEDIATION_TEXT = "For directions on AWS Best practices, please click this link"
REMEDIATION_LINK = "https://owasp.org/www-project-top-ten/"
report_url = "https://aws.amazon.com"

def process_message(event):
    """ Process Lambda Event """
    if event['messageType'] == 'CodeScanReport':
        account_id = boto3.client('sts').get_caller_identity().get('Account')
        region = os.environ['AWS_REGION']
        created_at = event['createdAt']
        source_repository = event['source_repository']
        source_branch = event['source_branch']
        source_commitid = event['source_commitid']
        build_id = event['build_id']
        report_type = event['reportType']
        finding_type = FINDING_TYPE_TEMPLATE.format(report_type)
        generator_id = f"{report_type.lower()}-{source_repository}-{source_branch}"
        ### upload to S3 bucket
        s3 = boto3.client('s3')
        s3bucket = "logging-bucket-" + account_id
        key = f"reports/{event['reportType']}/{build_id}-{created_at}.json"
        s3.put_object(Bucket=s3bucket, Body=json.dumps(event), Key=key, ServerSideEncryption='aws:kms')
        report_url = f"https://s3.console.aws.amazon.com/s3/object/{s3bucket}/{key}?region={region}"

        ### Checkov
        if event['reportType'] == 'checkov':  
            severity = 50
            FINDING_TITLE = "Checkov IaC Scan"
            alert_count = event['report'][0]['summary']['failed']
            count = 0
            for alertno in range(alert_count):
                count += 1
                risk_desc = f"{event['report'][0]['results']['failed_checks'][alertno]['check_name']}"
                REMEDIATION_LINK = f"{event['report'][0]['results']['failed_checks'][alertno]['guideline']}"
                ### set the vulnerability severity level
                normalized_severity = 50
                finding_description = f"{count}: {event['report'][0]['results']['failed_checks'][alertno]['check_id']} \n- {event['report'][0]['results']['failed_checks'][alertno]['check_name']}"
                finding_description = finding_description[0:1023]
                created_at = datetime.now(timezone.utc).isoformat()
                finding_id = f"{count}-{report_type.lower()}-{build_id}"
                REMEDIATION_TEXT = "Click this link to see Checkov guideline"
                ### get otherinfo
                resource =  f"{event['report'][0]['results']['failed_checks'][alertno]['resource']}"
                file_path = f"{event['report'][0]['results']['failed_checks'][alertno]['file_path']}"
                file_line_range = f"Line {event['report'][0]['results']['failed_checks'][alertno]['file_line_range'][0]} ~ {event['report'][0]['results']['failed_checks'][alertno]['file_line_range'][1]}"
                finding_note = f"File Path: {file_path} \n Resource: {resource} \n Line Range: \n {file_line_range}" 
                ### Calling Securityhub function to post the findings
                securityhub.import_finding_to_sh(count, account_id, region, created_at, source_repository, source_branch, source_commitid, build_id, report_url, finding_id, generator_id, normalized_severity, severity, finding_type, FINDING_TITLE, finding_description, finding_note, REMEDIATION_TEXT, REMEDIATION_LINK)
        
        else:
            print("Invalid report type was provided")                
    else:
        logger.error("Report type not supported:")

def lambda_handler(event, context):
    """ Lambda entrypoint """
    #pprint(event)
    try:
        logger.info("Starting function")
        return process_message(event)
    except Exception as error:
        logger.error("Error {}".format(error))
        raise